Professor, não foi possível deixar o projeto público.
Portanto te coloquei na organização e te adicionei como administrador.

segue link-

https://dev.azure.com/RM551600/MAI

Em caso de erro, aqui estão minhas credenciais

rm551600@fiap.com.br
Fiap43ZWL$